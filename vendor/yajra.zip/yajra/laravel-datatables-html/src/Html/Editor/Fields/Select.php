<?php

namespace Yajra\DataTables\Html\Editor\Fields;

class Select extends Field
{
    protected $type = 'select';
}
